from controller import Supervisor

# Custom traffic light controller (RED <-> GREEN)

sup = Supervisor()
timestep = int(sup.getBasicTimeStep())

# timings (seconds)
RED_TIME = 10.0     # 🔴 RED = 10 seconds
GREEN_TIME = 5.0    # 🟢 GREEN = 5 seconds

state = "RED"
timer = 0.0

def set_color(r, g, b):
    me = sup.getSelf()
    children = me.getField("children")
    shape = children.getMFNode(0)  # first child
    appearance = shape.getField("appearance").getSFNode()
    material = appearance.getField("material").getSFNode()
    material.getField("diffuseColor").setSFColor([r, g, b])
    material.getField("emissiveColor").setSFColor([r, g, b])

# start with RED
set_color(1, 0, 0)

while sup.step(timestep) != -1:
    timer += timestep / 1000.0

    if state == "RED" and timer >= RED_TIME:
        state = "GREEN"
        timer = 0.0
        set_color(0, 1, 0)

    elif state == "GREEN" and timer >= GREEN_TIME:
        state = "RED"
        timer = 0.0
        set_color(1, 0, 0)

