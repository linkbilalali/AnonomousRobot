# ===========================================================
# FINAL AUTONOMOUS CAR CONTROLLER (Webots + Python)
# - Lane following (yellow divider) [STABLE + MEMORY]
# - Custom Traffic Light detection (RED / GREEN) via camera
# - Simple NLP via commands.txt
# ===========================================================

from vehicle import Driver
import cv2
import numpy as np

# ---------------- Driver ----------------
driver = Driver()
TIME_STEP = int(driver.getBasicTimeStep())

# ---------------- Camera ----------------
camera = driver.getDevice("camera")
camera.enable(TIME_STEP)
IMG_W = camera.getWidth()
IMG_H = camera.getHeight()

# ---------------- Speeds ----------------
MAX_SPEED = 25
SLOW_SPEED = 10

driver.setCruisingSpeed(MAX_SPEED)

# ---------------- Lane memory ----------------
last_steer = 0.0

# ===========================================================
# Read commands (simple NLP)
# ===========================================================
def read_command():
    try:
        with open("commands.txt", "r") as f:
            return f.read().strip().upper()
    except:
        return ""

# ===========================================================
# Detect CUSTOM traffic light color (TOP area)
# ===========================================================
def detect_signal_color(image):
    img = np.frombuffer(image, np.uint8).reshape((IMG_H, IMG_W, 4))
    hsv = cv2.cvtColor(img[:, :, :3], cv2.COLOR_BGR2HSV)

    # top area only (traffic light)
    roi = hsv[0:int(IMG_H * 0.4), :]

    red1 = cv2.inRange(roi, (0,120,70), (10,255,255))
    red2 = cv2.inRange(roi, (170,120,70), (180,255,255))
    red = red1 + red2

    green = cv2.inRange(roi, (36,50,70), (89,255,255))

    if cv2.countNonZero(red) > 80:
        return "RED"
    if cv2.countNonZero(green) > 80:
        return "GREEN"
    return "NONE"

# ===========================================================
# Lane Following (Yellow Divider)
# ===========================================================
def lane_following(image):
    img = np.frombuffer(image, np.uint8).reshape((IMG_H, IMG_W, 4))
    hsv = cv2.cvtColor(img[:, :, :3], cv2.COLOR_BGR2HSV)

    mask = cv2.inRange(hsv, (20,100,100), (35,255,255))
    bottom = mask[int(IMG_H * 0.6):IMG_H, :]

    if cv2.countNonZero(bottom) < 80:
        return None

    col_sum = np.sum(bottom, axis=0)
    lane_center = int(np.argmax(col_sum))

    steer = ((lane_center / IMG_W) - 0.5) * 0.8
    return max(min(steer, 0.4), -0.4)

# ===========================================================
# MAIN LOOP
# ===========================================================
print(">>> FINAL AUTONOMOUS CAR RUNNING (CUSTOM TRAFFIC LIGHT)")

while driver.step() != -1:

    image = camera.getImage()
    command = read_command()

    signal = detect_signal_color(image)
    lane_steer = lane_following(image)

    # -------- PRIORITY 1: commands.txt --------
    if "STOP" in command:
        driver.setCruisingSpeed(0)
        driver.setSteeringAngle(0)
        continue

    if "TURN LEFT" in command:
        driver.setCruisingSpeed(SLOW_SPEED)
        driver.setSteeringAngle(0.4)
        continue

    if "TURN RIGHT" in command:
        driver.setCruisingSpeed(SLOW_SPEED)
        driver.setSteeringAngle(-0.4)
        continue

    # -------- PRIORITY 2: Custom Traffic Light --------
    if signal == "RED":
        driver.setCruisingSpeed(0)
        driver.setSteeringAngle(0)
        continue
    elif signal == "GREEN":
        driver.setCruisingSpeed(MAX_SPEED)

    # -------- PRIORITY 3: Lane following --------
    if lane_steer is not None:
        last_steer = lane_steer
        driver.setSteeringAngle(lane_steer)
    else:
        driver.setSteeringAngle(last_steer * 0.9)
